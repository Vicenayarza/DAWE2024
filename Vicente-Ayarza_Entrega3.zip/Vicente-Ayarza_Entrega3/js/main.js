import { nombresProductos, productosPorTipo } from './tienda.js';
import Balon from './balones.js'; // Importa la clase Libro
import Camiseta from './camisetas.js';
import Zapatilla from './zapatillas.js';

window.onload = () => {
    const columnas = document.querySelectorAll('.columna');

    columnas.forEach((columna, index) => {
        const titulo = document.createElement('h2');
        titulo.textContent = nombresProductos[index];
        columna.appendChild(titulo);

        productosPorTipo[index].forEach(producto => {
            const divProducto = document.createElement('div');
            divProducto.innerHTML = formatProducto(producto);
            columna.appendChild(divProducto);
        });
    });
};

function formatProducto(producto) {
    return `
        <div class="producto">
        <div>${producto.getNombre()}</div>
        <span>Precio: <b>${producto.getPrecio()}€</b></span>
        ${producto instanceof Balon ? `<span>Talla: <b>${producto.getTalla()}</b></span>` : ''}
        ${producto instanceof Camiseta ? `<span>Equipo: <b>${producto.getEquipo()}</b></span>` : ''}
        ${producto instanceof Zapatilla ? `<span>Marca: <b>${producto.getMarca()}</b></span>` : ''}
        </div>
    `;
}
