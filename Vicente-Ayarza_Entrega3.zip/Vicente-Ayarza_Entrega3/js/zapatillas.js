import Producto from './producto.js';

class Zapatilla extends Producto {
    constructor(nombre, precio, marca) {
        super(nombre, precio);
        this.marca = marca;
    }

    getMarca() {
        return this.marca;
    }

    setMarca(marca) {
        this.marca = marca;
    }

    static tipo() {
        return "Zapatillas";
    }
}

export default Zapatilla;
