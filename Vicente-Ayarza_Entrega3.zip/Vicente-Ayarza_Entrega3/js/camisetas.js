import Producto from './producto.js';

class Camiseta extends Producto {
    constructor(nombre, precio, equipo) {
        super(nombre, precio);
        this.equipo = equipo;
    }

    getEquipo() {
        return this.equipo;
    }

    setEquipo(equipo) {
        this.equipo = equipo;
    }

    static tipo() {
        return "Camisetas";
    }
}

export default Camiseta;
