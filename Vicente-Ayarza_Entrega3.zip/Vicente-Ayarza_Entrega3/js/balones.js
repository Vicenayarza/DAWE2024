import Producto from './producto.js';

class Balon extends Producto {
    constructor(nombre, precio, talla) {
        super(nombre, precio);
        this.talla = talla;
    }

    getTalla() {
        return this.talla;
    }

    setTalla(talla) {
        this.talla = talla;
    }

    static tipo() {
        return "Balon";
    }
}

export default Balon;
