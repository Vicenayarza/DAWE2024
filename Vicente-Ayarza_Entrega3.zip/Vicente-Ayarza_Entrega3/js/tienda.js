import Balon from './balones.js';
import Camiseta from './camisetas.js';
import Zapatilla from './zapatillas.js';

const productos = [
    new Balon("Wilson Evolution", 30, "7"),
    new Balon("Nike Elite", 25, "6"),
    new Balon("Spalding NBA Street", 20, "5"),
    new Balon("Molten BGGX", 40, "7"),
    new Balon("Adidas Pro", 35, "6"),
    new Camiseta("Nike LeBron James", 80, "Los Angeles Lakers"),
    new Camiseta("Adidas Kevin Durant", 70, "Brooklyn Nets"),
    new Camiseta("Jordan Kobe Bryant", 85, "Los Angeles Lakers"),
    new Camiseta("Under Armour Stephen Curry", 75, "Golden State Warriors"),
    new Camiseta("Puma Giannis Antetokounmpo", 90, "Milwaukee Bucks"),
    new Zapatilla("Air Jordan 1", 150, "Nike"),
    new Zapatilla("Adidas UltraBoost", 180, "Adidas"),
    new Zapatilla("New Balance 990", 160, "New Balance"),
    new Zapatilla("Puma Clyde Court", 120, "Puma"),
    new Zapatilla("Under Armour Curry 8", 160, "Under Armour"),
   
];

const nombresProductos = [
    Balon.tipo(),
    Camiseta.tipo(),
   Zapatilla.tipo()
];

const productosPorTipo = [
    productos.filter(producto => producto instanceof Balon),
    productos.filter(producto => producto instanceof Camiseta),
    productos.filter(producto => producto instanceof Zapatilla)
];

export { nombresProductos, productosPorTipo };
