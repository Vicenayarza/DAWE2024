import Producto from './producto.js';

class Balon extends Producto {
    constructor(nombre, precio, talla) {
        super(nombre, precio);
        this.talla = talla;
    }

    get Talla() {
        return this.talla;
    }

    set Talla(talla) {
        this.talla = talla;
    }

    static tipo() {
        return "Balon";
    }
}

export default Balon;
