import { productosPorTipo } from './tienda.js';
import Balon from './balones.js'; 
import Camiseta from './camisetas.js';
import Zapatilla from './zapatillas.js';

window.onload = () => {
    cargarGestoresEventos();
};

function cargarGestoresEventos() {
    const columnas = document.querySelectorAll('.columna');

    columnas.forEach((columna, index) => {
        const productos = productosPorTipo[index];

        productos.forEach(producto => {
            const divProducto = document.createElement('div');
            divProducto.innerHTML = formatProducto(producto);
            columna.appendChild(divProducto);

            const botonComprar = divProducto.querySelector('.boton-comprar');
            const spinner = divProducto.querySelector('.spinner');
            
            botonComprar.addEventListener('click', () => agregarAlCarrito(producto, spinner));
            spinner.addEventListener('change', actualizarBotonCompra.bind(null, botonComprar, spinner));
        });
    });
}

function agregarAlCarrito(producto, spinner) {
    const cantidad = parseInt(spinner.value);

    if (cantidad > 0) {
        // Limpiar el nombre del producto para evitar espacios en blanco
        const nombreProductoLimpiado = producto.Nombre.replace(/\s+/g, '-');

        const totalEnCarrito = document.querySelectorAll(`#items-carrito .item-${nombreProductoLimpiado}`).length;

        if (totalEnCarrito + cantidad <= 9) {
            for (let i = 0; i < cantidad; i++) {
                const itemCarrito = document.createElement('div');
                itemCarrito.textContent = producto.Nombre;
                itemCarrito.classList.add(`item-${nombreProductoLimpiado}`);
                document.querySelector('#items-carrito').appendChild(itemCarrito);
            }
        } else {
            alert('No se pueden agregar más de 9 copias del mismo producto al carrito.');
        }

        // Mostrar el carrito solo si hay productos en él
        document.getElementById('carrito').removeAttribute('hidden');
    }
}


function actualizarBotonCompra(botonComprar, spinner) {
    if (spinner.value > 0 && spinner.value <= 9) {
        botonComprar.textContent = `Comprar ${spinner.value}`;
        botonComprar.disabled = false;
    } else {
        botonComprar.textContent = 'Comprar';
        botonComprar.disabled = true;
    }
}

function formatProducto(producto) {
    return `
    <div class="producto">
        <div>${producto.Nombre}</div>
        <span>Precio: <b>${producto.Precio}€</b></span>
        ${producto instanceof Balon ? `<span>Talla: <b>${producto.Talla}</b></span>` : ''}
        ${producto instanceof Camiseta ? `<span>Equipo: <b>${producto.Equipo}</b></span>` : ''}
        ${producto instanceof Zapatilla ? `<span>Marca: <b>${producto.Marca}</b></span>` : ''}
        <div class="acciones">
            <input type="number" class="spinner" value="0" min="0" max="9">
            <button class="boton-comprar" disabled>Comprar</button>
        </div>
    </div>
`;
}

const carrito = document.getElementById('carrito');

// Evento para aumentar el ancho del carrito al pasar el ratón sobre él
carrito.addEventListener('mouseenter', function() {
    this.style.width = '400px'; // Aumentar el ancho del carrito al pasar el ratón sobre él
});

// Evento para restaurar el ancho original del carrito al retirar el ratón del mismo
carrito.addEventListener('mouseleave', function() {
    this.style.width = '300px'; // Restaurar el ancho original del carrito al salir del mismo
});
