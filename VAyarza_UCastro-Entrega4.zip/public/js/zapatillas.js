import Producto from './producto.js';

class Zapatilla extends Producto {
    constructor(nombre, precio, marca) {
        super(nombre, precio);
        this.marca = marca;
    }

    get Marca() {
        return this.marca;
    }

    set Marca(marca) {
        this.marca = marca;
    }

    static tipo() {
        return "Zapatillas";
    }
}

export default Zapatilla;
