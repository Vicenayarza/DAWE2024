class Producto {
    constructor(nombre, precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    get Nombre() {
        return this.nombre;
    }

    set Nombre(nombre) {
        this.nombre = nombre;
    }

    get Precio() {
        return this.precio;
    }

    set Precio(precio) {
        this.precio = precio;
    }
}

export default Producto;
