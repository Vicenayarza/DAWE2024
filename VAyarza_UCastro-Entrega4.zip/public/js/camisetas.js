import Producto from './producto.js';

class Camiseta extends Producto {
    constructor(nombre, precio, equipo) {
        super(nombre, precio);
        this.equipo = equipo;
    }

    get Equipo() {
        return this.equipo;
    }

    set Equipo(equipo) {
        this.equipo = equipo;
    }

    static tipo() {
        return "Camisetas";
    }
}

export default Camiseta;
