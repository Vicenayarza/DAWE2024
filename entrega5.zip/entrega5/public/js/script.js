document.getElementById("obtenerDatos").addEventListener("click", function() {
    var isbn = document.getElementById("libros").value;
    fetch("https://openlibrary.org/api/books?bibkeys=ISBN:" + isbn + "&jscmd=data&format=json").then(function(response) {
        return response.json();
    }).then(function(data) {
        var libro = data["ISBN:" + isbn];
        var titulo = libro.title;
        var autores = libro.authors.map(function(author) {
            return author.name;
        }).join(", ");
        var imagen = libro.cover.medium;
        var resultado = document.getElementById("resultado");
        resultado.innerHTML = "<h2>" + titulo + "</h2><p>" + autores + "</p><img src='" + imagen + "' alt='" + titulo + "' />";
    }).catch(function(error) {
        console.log(error);
    });
});
