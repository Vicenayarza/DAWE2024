window.onload = () => {
    // Función para añadir un enlace a una lista <ul>
    function agregarEnlace(ulSelector, textoEnlace) {
        const ul = document.querySelector(ulSelector);
        const li = document.createElement('li');
        const a = document.createElement('a');
        a.textContent = textoEnlace;
        li.appendChild(a);
        ul.appendChild(li);
    }

    // Añadir un <section> con <h1> y 3 <article> después del primer <section>
    const main = document.querySelector('main');
    const primeraSection = main.querySelector('section');
    const nuevaSection = document.createElement('section');
    const h1 = document.createElement('h1');
    h1.textContent = 'Entrega 2';
    nuevaSection.appendChild(h1);
    for (let i = 0; i < 3; i++) {
        const article = document.createElement('article');
        article.textContent = `Artículo ${i+1} de la entrega 2 de nuestra web sobre baloncesto,deporte de equipo que se puede desarrollar tanto en pista cubierta como en descubierta, en el que dos conjuntos de cinco jugadores cada uno, intentan anotar puntos, también llamados canastas o dobles y/o triples introduciendo un balón en un aro colocado a 3,05 metros del suelo del que cuelga una red, lo que le da un aspecto de cesta o canasta.`;
        nuevaSection.appendChild(article);
    }
    main.insertBefore(nuevaSection, primeraSection.nextElementSibling);

    // Añadir enlaces adicionales
    agregarEnlace('aside ul', 'Entrega2Competición ');
    agregarEnlace('aside ul', 'Entrega2Tutoriales');
    agregarEnlace('aside ul', 'Entrega2Ejercicios');
    agregarEnlace('nav ul', 'Entraga2Principal');
    agregarEnlace('footer ul', 'Entrega2 Ranking Copa');

    // Cambiar estilo de los elementos
    const articles = document.querySelectorAll('article');
    articles.forEach(article => {
        article.style.fontSize = 'smaller';
    });

    const asideLinks = document.querySelectorAll('aside a');
    asideLinks.forEach(link => {
        link.style.textDecoration = 'none';
        link.style.fontStyle = 'italic';
    });

    const navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(link => {
        link.style.fontSize = 'smaller';
        link.style.fontWeight = 'bold';
    });

    // Imprimir número de elementos <li>
    const liElements = document.querySelectorAll('li');
    console.log(`Cantidad de  <li>: ${liElements.length}`);
}